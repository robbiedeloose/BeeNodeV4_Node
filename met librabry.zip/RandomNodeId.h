#ifndef RandomNodeId_h
#define RandomNodeId_h

#include <Arduino.h>
#include <EEPROM.h>

typedef struct {
  byte nodeId[4];
  byte nodeAddress;
  float hiveTemps[3];
} NodeData_t;

class RandomNodeId {
public:
  RandomNodeId() { ; }
  void getId(byte *nodeId);
  void getId2(NodeData_t *nodeData);

private:
};

#endif
