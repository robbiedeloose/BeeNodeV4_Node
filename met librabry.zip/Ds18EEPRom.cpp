#include "Ds18EEPRom.h"
#include <DallasTemperature.h> // for ds18
#include <EEPROM.h>
#include <OneWire.h>
#include <arduino.h>

#define ONE_WIRE_BUS A0
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

Ds18EEPRom::Ds18EEPRom(uint8_t numberOfSensors, int EEPRomLocation) {
  _numberOfSensors = numberOfSensors;
  _EEPRomLocation = EEPRomLocation;
  loadDS18Addresses();
  sensors.begin();
}

void Ds18EEPRom::loadDS18Addresses() {
  int startByte = 6;
  for (int a = 0; a < _numberOfSensors; a++) {
    for (int i = 0; i < 8; i++) {
      _deviceAddress[a][i] = EEPROM.read(i + _EEPRomLocation + (8 * a));
    }
  }
}

void Ds18EEPRom::getDS18Addresses(byte *addressArray) {
  int startByte = 6;
  for (int a = 0; a < _numberOfSensors; a++) {
    for (int i = 0; i < 8; i++) {
      addressArray[a][i] = EEPROM.read(i + _EEPRomLocation + (8 * a));
    }
  }
}
