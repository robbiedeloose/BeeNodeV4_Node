
#ifndef ds18EEPRom_h
#define ds18EEPRom_h

#include <DallasTemperature.h>
#include <EEPROM.h>
#include <OneWire.h>
#include <arduino.h>

class Ds18EEPRom {
public:
  Ds18EEPRom(uint8_t numberOfSensors, int EEPRomLocation);
  void getDS18Addresses(byte *addressArray);
  uint8_t _deviceAddress[6][8];

private:
  void loadDS18Addresses();
  uint8_t _numberOfSensors;
  int _EEPRomLocation;
};

#endif
